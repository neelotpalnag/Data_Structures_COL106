The Mult1_runtime_log.xlsx shows the variation of 
Running Time with input size. 
Similar graphs can be generated for Mult2/3/4, using 
$javac Test.java
$java Test -> Mult2/3/4.txt
 and then plotting using excel.