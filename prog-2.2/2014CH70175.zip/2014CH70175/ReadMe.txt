User can compile the testMe.java file to check the 
functioning of the *.java files. Relevant commands
for the different codes need to be uncommented and 
objects need to be made before running
 