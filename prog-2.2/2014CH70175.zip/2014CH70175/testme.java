import java.util.*;

public class Test{
  public static void main(String[] args) {
  myQueueUsingDynamicArray A=new myQueueUsingDynamicArray();
  System.out.println(A.getSize());
  A.enqueue(13);
  A.printQueue();
  System.out.println(A.getSize());
  A.enqueue(15);
  A.printQueue();
  System.out.println(A.getSize());
  A.enqueue(14);
  A.enqueue(15);
  A.enqueue(16);
  A.enqueue(17);
  A.enqueue(18);
  A.enqueue(19);
  A.enqueue(20);
  System.out.println(A.getSize());
  A.printQueue();
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());
  System.out.println("All Good 3");
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());
  System.out.println("All Good 2");
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println("All Good 1");
  System.out.println(A.getSize());
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());
  System.out.println("All Good 0");

 A.enqueue(14);
 System.out.println("All Good -1");
  A.enqueue(15);
  System.out.println("All Good -2");
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());
  A.enqueue(16);
  A.enqueue(17);
  A.printQueue();
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  System.out.println("All Good 0");
  A.printQueue();
  System.out.println(A.getSize());
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());
  A.enqueue(18);
  A.enqueue(19);
  A.enqueue(20);
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());
  A.enqueue(14);
  A.enqueue(15);
  A.enqueue(16);
  A.enqueue(17);
  A.enqueue(18);
  A.enqueue(19);
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());
  A.enqueue(20);
  try{
  System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
  A.printQueue();
  System.out.println(A.getSize());  try{
    System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
    A.printQueue();
    System.out.println(A.getSize());  try{
      System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
      A.printQueue();
      System.out.println(A.getSize());  try{
        System.out.println(A.dequeue());}catch(Exception q){ q.printStackTrace();}
        A.printQueue();
        System.out.println(A.getSize());
    /*myStackUsingDynamicArray A = new myStackUsingDynamicArray();
  A.printStack();
  A.push(23);
  A.printStack();
  A.push(24);
  A.printStack();
  A.push(25);
  A.printStack();
  A.push(26);
  A.printStack();
  A.getSize();
  A.push(27);
  A.printStack();
  A.push(28);
  A.printStack();
  A.push(29);
  A.printStack();
  A.push(30);
  A.printStack();
  A.push(31);
  A.printStack();
  A.push(32);
  A.printStack();
  System.out.println("Now begins POPPING!");
  A.pop();
  A.printStack();
  System.out.println("Now begins POPPING!");
  A.pop();
  A.printStack();
  System.out.println("Now begins POPPING!");
  A.pop();
  A.printStack();
  System.out.println("Now begins POPPING!");
  A.pop();
  A.printStack();
  System.out.println("Now begins POPPING!");
  A.pop();
  A.printStack();*/
}
}
